<?php

return [
    'title' => 'অ্যাপ ব্যানার',
'singular_title' => 'অ্যাপ ব্যানার',
'lbl_name' => 'নাম',
'lbl_link' => 'ইউআরএল',
'lbl_type' => 'ধরণ',
'lbl_link_id' => 'লিংক আইডি',
'lbl_status' => 'অবস্থা',
'lbl_file_url' => 'ফিচার ইমেজ',
'lbl_action' => 'ক্রিয়া',

];
