<?php

return [
    'lbl_razorpay' => 'রেজরপে',
    'lbl_secret_key' => 'গোপন কী',
    'lbl_app_key' => 'অ্যাপ কী',
    'lbl_stripe' => 'স্ট্রাইপ',
    'lbl_paystack' => 'পে স্ট্যাক',
    'lbl_paypal' => 'পেপ্যাল',
    'lbl_flutterwave' => 'ফ্লাটারওেভ',
    'lbl_client_id' => 'ক্লায়েন্ট আইডি',

];
