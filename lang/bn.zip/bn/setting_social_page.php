<?php

return [
   'lbl_fb_url' => 'ফেসবুক পেজ URL (facebook_url)',
'lbl_twitter_url' => 'টুইটার প্রোফাইল URL (twitter_url)',
'lbl_insta_url' => 'ইনস্টাগ্রাম অ্যাকাউন্ট URL (instagram_url)',
'lbl_linkedin_url' => 'লিঙ্কডইন URL (linkedin_url)',
'lbl_youtube_url' => 'ইউটিউব চ্যানেল URL (youtube_url)',

];
