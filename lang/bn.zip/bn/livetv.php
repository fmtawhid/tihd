<?php

return[
    'title' => 'টিভি ক্যাটাগরি',
'add_title' => 'নতুন টিভি ক্যাটাগরি',
'edit_title' => 'টিভি ক্যাটাগরি সম্পাদনা',
'add_tvchannel' => 'নতুন টিভি চ্যানেল',
'edit_tvchannel' => 'টিভি চ্যানেল সম্পাদনা',
'checkall' => 'সব চেক করুন',
'title-livetv' => 'লাইভ টিভি',
'lbl_name' => 'নাম',
'livetv_category_list' => 'লাইভ টিভি ক্যাটাগরি তালিকা',
'tvchannel' => 'টিভি চ্যানেল',
'tvchannel_updated' => 'টিভি চ্যানেল আপডেটed',
'tvchannel_added' => 'টিভি চ্যানেল যোগ করা হয়েছে',
'livetv_dashboard' => 'লাইভ টিভি ড্যাশবোর্ড',
'livetv_details' => 'লাইভ টিভি বিস্তারিত',
'description' => 'বর্ণনা',
'access' => 'অ্যাক্সেস',
'plan' => 'প্ল্যান',
'channel_list' => 'লাইভ টিভি চ্যানেল তালিকা',

];
