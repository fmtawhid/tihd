<?php

return [
   'title' => 'রাজ্য',
'add_title' => 'নতুন রাজ্য',
'edit_title' => 'রাজ্য সম্পাদনা করুন',
'singule_title' => 'রাজ্য',

];
