<?php

return [
    'title' => 'শহর',
'add_title'=>'নতুন শহর',
'edit_title'=>'শহর সম্পাদনা',
'singular_title' => 'শহর',
'state_name' => 'রাজ্যের নাম',
'state' => 'রাজ্য',

];
