<?php

return [
    'title'=>'অ্যাপ ব্যানার',
'add_title'=>'নতুন অ্যাপ ব্যানার',
'edit_title'=>'অ্যাপ ব্যানার সম্পাদনা',
'lbl_image' => 'ছবি',
'lbl_title' => 'শিরোনাম',
'lbl_select' => 'নির্বাচন করুন',
'lbl_type' => 'প্রকার',
'lbl_name' => 'নাম',
'lbl_status' => 'স্থিতি',
'lbl_update_at' => 'সর্বশেষ আপডেট',
'lbl_action' => 'ক্রিয়া',
'status_update'=> 'স্থিতি সফলভাবে আপডেট হয়েছে!',


];
