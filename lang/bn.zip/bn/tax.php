<?php

return [
   'title' => 'কর',
'lbl_title' => 'শিরোনাম',
'lbl_value' => 'মান',
'lbl_select_type' => 'ধরন নির্বাচন করুন',
'lbl_Type' => 'ধরন',
'lbl_status' => 'অবস্থা',
'lbl_action' => 'ক্রিয়া',
'lbl_module_type' => 'মডিউল ধরন',


];
