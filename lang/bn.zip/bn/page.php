<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'title' => 'পৃষ্ঠাসমূহ',
'lbl_title' => 'শিরোনাম',
'lbl_description' => 'বর্ণনা',
'lbl_sequence' => 'ক্রম',
'lbl_status' => 'স্থিতি',
'lbl_action' => 'ক্রিয়া',
'lbl_name' => 'নাম',
'lbl_more_permission' => 'আরো অনুমতি যোগ করুন',
'lbl_role' => 'ভূমিকা',
'lbl_import' => 'ভূমিকা থেকে আমদানি করুন',
'status_updated' => 'স্থিতি সফলভাবে আপডেট হয়েছে!',

];
