<?php 

return[
   'title' => 'মিডিয়া'
'file_added' => 'ফাইল সফলভাবে যোগ করা হয়েছে!'

];