<?php

return [
   'title' => 'দেশগুলি',
'add_title' => 'নতুন দেশ',
'edit_title' => 'দেশ সম্পাদনা',
'singular_title' => 'দেশ',

];
