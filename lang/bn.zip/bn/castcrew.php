<?php

return [

   'actor_title' => 'অভিনেতা',
'title_add_new_castcrew' => 'নতুন কাস্ট যোগ করুন',
'castcrew_title' => 'কাস্ট ক্রু',
'lbl_name' => 'নাম',
'lbl_bio' => 'জীবনী',
'lbl_type' => 'ধরণ',
'lbl_birth_place' => 'জন্মস্থান',
'lbl_designation' => 'পদবী',
'lbl_dob' => 'জন্ম তারিখ',
'lbl_image' => 'ছবি',
'title_edit_castcrew' => 'কাস্ট ক্রু সম্পাদনা করুন',
'actors' => 'অভিনেতা',
'directors' => 'পরিচালক',
'add_actor' => 'নতুন অভিনেতা যোগ করুন',
'add_director' => 'নতুন পরিচালক যোগ করুন',
'edit_actor' => 'অভিনেতা সম্পাদনা করুন',
'edit_director' => 'পরিচালক সম্পাদনা করুন',
'castcrew_list' => 'কাস্ট ক্রু তালিকা',
'lbl_actor' => 'অভিনেতা',
'lbl_director' => 'পরিচালক',

];