<?php

return [
  'title' => 'ব্যবহারকারী',
'lbl_profile_image' => 'প্রোফাইল ছবি',
'lbl_first_name' => 'প্রথম নাম',
'lbl_last_name' => 'শেষ নাম',
'lbl_Email' => 'ইমেইল',
'lbl_phone_number' => 'ফোন নম্বর',
'lbl_gender' => 'লিঙ্গ',
'lbl_status' => 'স্ট্যাটাস',
'lbl_verification_status' => 'যাচাইকরণ স্ট্যাটাস',
'lbl_blocked' => 'ব্লকড',
'msg_verified' => 'যাচাইকৃত',
'msg_unverified' => 'যাচাই করতে হবে',
'lbl_action' => 'কর্ম',
'lbl_date_of_birth' => 'জন্ম তারিখ',
'lbl_name' => 'নাম',
'about' => 'সম্পর্কে',
'total_reviews' => 'মোট পর্যালোচনা',
'other_details' => 'অন্যান্য বিস্তারিত',
'reviews' => 'পর্যালোচনা',
'data_not_found' => 'তথ্য পাওয়া যায়নি',
'view_all' => 'সকল দেখুন',
'email_sent' => 'ইমেইল সফলভাবে পাঠানো হয়েছে!'

];
