<?php

return [
    'lbl_primary' => 'প্রাথমিক',
'lbl_secondary' => 'মাধ্যমিক',
'lbl_app_id' => 'অ্যাপ আইডি',
'lbl_security' => 'অ্যাপ সিকিউরিটি',

];
