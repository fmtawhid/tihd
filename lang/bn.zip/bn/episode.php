<?php

return [
  'title' => 'এপিসোড',
'add_title' => 'নতুন এপিসোড',
'edit_title' => 'এপিসোড সম্পাদনা',
'singular_title' => 'এপিসোড',
'lbl_season' => 'সিজন',
'lbl_import' => 'ইম্পোর্ট',
'lbl_remove' => 'অপসারণ',
'lbl_add_more' => 'আরো যোগ করুন',
'already_added_episode' => 'এপিসোডটি ইতিমধ্যে যোগ করা হয়েছে',
'select_seson' => 'সিজন নির্বাচন করুন',
'select_episode' => 'এপিসোড নির্বাচন করুন',
'episode' => 'এপিসোড',
'download_episode' => 'এপিসোড ডাউনলোড করুন',
'access' => 'অ্যাক্সেস',
'plan' => 'প্ল্যান',
'lbl_free' => 'ফ্রি',
'lbl_paid' => 'পেইড',

  
];
