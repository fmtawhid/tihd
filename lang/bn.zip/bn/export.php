<?php

return[
   'title' => 'ডেটা রপ্তানি করুন',
'lbl_date' => 'তারিখ',
'lbl_select_file_type' => 'ফাইলের ধরন নির্বাচন করুন',
'lbl_select_columns' => 'কলাম নির্বাচন করুন',
'download' => 'ডাউনলোড',
'cancel' => 'বাতিল'

];
