<?php

return [
    'lbl_css_name' => 'কাস্টম সিএসএস কোড (custom_css_block)',  
'lbl_js_name' => 'কাস্টম জেএস কোড (custom_js_block)',  

];
