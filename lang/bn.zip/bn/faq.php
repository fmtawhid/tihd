<?php

return [
  'title' => 'প্রশ্নোত্তর',
'add_title' => 'প্রশ্নোত্তর যোগ করুন',
'edit_title' => 'প্রশ্নোত্তর সম্পাদনা করুন',
'lbl_question' => 'প্রশ্ন',
'enter_question' => 'প্রশ্ন লিখুন',
'lbl_answer' => 'উত্তর',
'enter_answer' => 'উত্তর লিখুন',
'lbl_status' => 'অবস্থা',

];