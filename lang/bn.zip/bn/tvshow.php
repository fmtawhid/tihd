<?php

return [
   'title' => 'সিরিজ',
'add_title' => 'নতুন সিরিজ',
'edit_title' => 'সিরিজ সম্পাদনা',
'lbl_title' => 'শিরোনাম',
'lbl_value' => 'মান',
'lbl_select_type' => 'টাইপ নির্বাচন করুন',
'lbl_Type' => 'টাইপ',
'lbl_status' => 'অবস্থা',
'lbl_action' => 'ক্রিয়া',
'lbl_module_type' => 'মডিউল টাইপ',
'details' => 'সিরিজের বিস্তারিত',
'lbl_import' => 'আমদানি',
'lbl_loading' => 'লোড হচ্ছে...',
'already_added_tvshow' => 'এই সিরিজটি ইতিমধ্যেই যোগ করা হয়েছে।'


];
