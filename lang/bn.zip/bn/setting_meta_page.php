<?php

return [
    'lbl_site_name' => 'মেটা সাইট নাম (meta_site_name)',
'lbl_description' => 'মেটা বর্ণনা (meta_description)',
'lbl_keyword' => 'মেটা কিওয়ার্ড (meta_keyword)',
'lbl_image' => 'মেটা ইমেজ (meta_image)',
'lbl_fb_app_id' => 'মেটা ফেসবুক অ্যাপ আইডি (meta_fb_app_id)',
'lbl_twitter_site' => 'মেটা টুইটার সাইট অ্যাকাউন্ট (meta_twitter_site)',
'lbl_twitter_creator' => 'মেটা টুইটার ক্রিয়েটর অ্যাকাউন্ট (meta_twitter_creator)',

];
