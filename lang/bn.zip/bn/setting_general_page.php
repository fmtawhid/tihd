<?php

return [
    'lbl_app' => 'ব্যবসার নাম',
'lbl_footer' => 'ফুটার টেক্সট',
'lbl_copyright' => 'কপিরাইট টেক্সট',
'lbl_uitext' => 'ইউআই টেক্সট',
'lbl_contact_no' => 'যোগাযোগ নম্বর',
'lbl_inquiry_email' => 'ইমেইল',
'lbl_site_description' => 'সংক্ষিপ্ত বিবরণ',
'business_add' => 'ঠিকানা',
'branding' => 'ব্র্যান্ডিং',
'lbl_user_app' => 'ইউজার অ্যাপের নাম',

];
