<?php

return[
  'title' => 'ধরণসমূহ',
'add_title' => 'নতুন ধরণ',
'edit_title' => 'ধরণ সম্পাদনা',
'lbl_name' => 'নাম',
'lbl_image' => 'চিত্র',
'lbl_select_file_type' => 'ফাইল প্রকার নির্বাচন করুন',
'lbl_select_columns' => 'কলাম নির্বাচন করুন',
'download' => 'ডাউনলোড',
'cancel' => 'বাতিল',
'add_genres' => 'নতুন',
'title_edit_genere' => 'ধরণ সম্পাদনা',
'title_add_new_genere' => 'নতুন ধরণ যোগ করুন',
'genres_list' => 'ধরণসমূহের তালিকা',

];
