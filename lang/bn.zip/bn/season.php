<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
   'title' => 'সিজনসমূহ',
'new_title'=>'নতুন সিজন',
'edit_title'=>'সিজন সম্পাদনা করুন',
'lbl_tv_shows'=>'সিরিজ',
'lbl_import'=> 'ইমপোর্ট',
'lbl_loading'=>'লোড হচ্ছে...',
'already_added_season'=>'সিজনটি ইতিমধ্যেই যুক্ত হয়েছে।',
'access' => 'অ্যাক্সেস',
'plan' => 'প্ল্যান',
'lbl_free'=>'ফ্রি',
'lbl_paid'=>'পেইড',

];