<?php

return [
   'lbl_email' => 'ইমেইল (email)',
'lbl_driver' => 'মেইল ড্রাইভার',
'lbl_host' => 'মেইল হোস্ট',
'lbl_port' => 'মেইল পোর্ট',
'lbl_encryption' => 'মেইল এনক্রিপশন',
'lbl_username' => 'মেইল ব্যবহারকারীর নাম',
'lbl_password' => 'পাসওয়ার্ড',
'lbl_mail' => 'যে ইমেইল থেকে মেইল যাবে',
'lbl_from_name' => 'প্রেরকের নাম',

];
