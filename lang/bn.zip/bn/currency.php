<?php

return [
   'title' => 'মুদ্রা',
'lbl_edit' => 'মুদ্রা সম্পাদন করুন',
'lbl_add' => 'নতুন মুদ্রা যোগ করুন',
'lbl_currency_name' => 'মুদ্রার নাম',
'lbl_currency_symbol' => 'মুদ্রার প্রতীক',
'lbl_currency_code' => 'মুদ্রা কোড',
'lbl_is_primary' => 'প্রাথমিক কি না',
'lbl_currency_position' => 'মুদ্রার অবস্থান',
'lbl_thousand_separatorn' => 'হাজারের বিভাজক',
'lbl_decimal_separator' => 'দশমিক বিভাজক',
'lbl_number_of_decimals' => 'দশমিকের সংখ্যা',
'lbl_ID' => 'আইডি',
'lbl_action' => 'অ্যাকশন',
'currency_format' => 'মুদ্রা ফরম্যাট সেটিংস',

];
