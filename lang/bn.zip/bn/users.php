<?php

return [
    
'title' => 'ব্যবহারকারীরা',
'lbl_name'=>'নাম',
'lbl_contact_number'=>'যোগাযোগ নম্বর',
'lbl_status'=>'অবস্থা',
'lbl_gender'=>'লিঙ্গ',
'lbl_last_name'=>'শেষ নাম',
'lbl_first_name'=>'প্রথম নাম',
'lbl_email'=>'ইমেল',
'lbl_password'=>'পাসওয়ার্ড',
'lbl_confirm_password'=>'পাসওয়ার্ড নিশ্চিত করুন',
'lbl_date_of_birth'=>'জন্মতারিখ',
'lbl_address'=>'ঠিকানা',
'lbl_edit_user'=>'ব্যবহারকারী সম্পাদনা করুন',
'lbl_add_new_user'=>'নতুন ব্যবহারকারী যোগ করুন',
'user_details' => 'ব্যবহারকারী বিস্তারিত',
'lbl_old_password'=> 'পুরানো পাসওয়ার্ড',
'lbl_new_password'=>'নতুন পাসওয়ার্ড',
'account_setting' => 'অ্যাকাউন্ট সেটিং',
'device_logout' => 'ডিভাইস থেকে লগআউট সফল!',
'delete_account' => 'অ্যাকাউন্ট সফলভাবে মুছে ফেলা হয়েছে!',
'lbl_user' => 'ব্যবহারকারী',
'device_not_found' => 'ডিভাইস পাওয়া যায়নি',
'soon_to_expire' => 'শীঘ্রই মেয়াদ উত্তীর্ণ হবে',

'lbl_subscription_details'=>'সাবস্ক্রিপশন বিস্তারিত',
'date'=>'সাবস্ক্রাইব তারিখ'



];
