<?php

return [
  'title' => 'পরিকল্পনা',
'singular_title' => 'সাবস্ক্রিপশন পরিকল্পনা',
'lbl_name' => 'নাম',
'lbl_type' => 'প্রকার',
'lbl_level' => 'স্তর',
'lbl_duration' => 'সময়কাল',
'lbl_duration_value' => 'সময়কাল মূল্য',
'lbl_amount' => 'মূল্য',
'lbl_plan_limitation' => 'পরিকল্পনার সীমাবদ্ধতা',
'lbl_description' => 'বিবরণ',
'lbl_status' => 'অবস্থা',
'lbl_select_limitation' => 'সীমাবদ্ধতা নির্বাচন করুন',
'lbl_set_limit' => 'সীমা নির্ধারণ করুন',
'lbl_edit_plan' => 'পরিকল্পনা সম্পাদনা করুন',
'lbl_add_new_plan' => 'নতুন পরিকল্পনা যোগ করুন',
'plan_list' => 'পরিকল্পনার তালিকা',
'lbl_device_limit' => 'ডিভাইস সীমা',
'lbl_plan_limits' => 'পরিকল্পনার সীমাবদ্ধতা',
'lbl_discount' => 'ছাড়',
'lbl_discount_percentage' => 'শতাংশ',
'enter_discount_percentage' => 'শতাংশ লিখুন',
'lbl_total_price' => 'মোট মূল্য',
'lbl_supported_device_type_options' => 'ডিভাইসের প্রকার',
'lbl_profile_limit' => 'প্রোফাইল সীমা'

    
];
