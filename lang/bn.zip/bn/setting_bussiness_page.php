<?php

return [
'lbl_app'=>'অ্যাপ',
'lbl_doctor_app'=>'ডাক্তার অ্যাপ',
'lbl_user_app'=>'ইউজার অ্যাপ',
'lbl_contact_no'=>'যোগাযোগ নম্বর',
'lbl_inquiry_email'=>'জিজ্ঞাসা ইমেইল',
'lbl_site_description'=>'সাইট বিবরণ',
'business_add'=>'ব্যবসা যোগ করুন',
'lbl_shop_number'=>'দোকান নম্বর',
'lbl_landmark'=>'ল্যান্ডমার্ক',
'lbl_country'=>'দেশ',
'lbl_state'=>'রাজ্য',
'lbl_city'=>'শহর',
'lbl_postal_code'=>'পোস্টাল কোড',
'lbl_lat'=>'অক্ষাংশ',
'lbl_long'=>'দ্রাঘিমাংশ',
'branding'=>'ব্র্যান্ডিং',
'dark_mini_logo'=>'ডার্ক মিনি লোগো',


];
