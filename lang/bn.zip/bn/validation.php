<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */

    'accepted' => ':attribute গ্রহণ করা উচিত।',
'accepted_if' => ':attribute গ্রহণ করা উচিত যখন :other হলো :value।',
'active_url' => ':attribute একটি বৈধ URL নয়।',
'after' => ':attribute একটি তারিখ হতে হবে :date এর পর।',
'after_or_equal' => ':attribute একটি তারিখ হতে হবে :date এর পর বা সমান।',
'alpha' => ':attribute শুধুমাত্র অক্ষর ধারণ করতে হবে।',
'alpha_dash' => ':attribute শুধুমাত্র অক্ষর, সংখ্যা, ড্যাশ এবং আন্ডারস্কোর ধারণ করতে হবে।',
'alpha_num' => ':attribute শুধুমাত্র অক্ষর এবং সংখ্যা ধারণ করতে হবে।',
'array' => ':attribute একটি অ্যারে হতে হবে।',
'before' => ':attribute একটি তারিখ হতে হবে :date এর আগে।',
'before_or_equal' => ':attribute একটি তারিখ হতে হবে :date এর আগে বা সমান।',
'between' => [
    'array' => ':attribute এর মধ্যে :min এবং :max আইটেম থাকতে হবে।',
    'file' => ':attribute এর আকার :min এবং :max কিলোবাইটের মধ্যে থাকতে হবে।',
    'numeric' => ':attribute :min এবং :max এর মধ্যে হতে হবে।',
    'string' => ':attribute :min এবং :max অক্ষরের মধ্যে হতে হবে।',
],
'boolean' => ':attribute ক্ষেত্রটি সত্য অথবা মিথ্যা হতে হবে।',
'confirmed' => ':attribute নিশ্চিতকরণ মেলেনি।',
'current_password' => 'পাসওয়ার্ড ভুল।',
'date' => ':attribute একটি বৈধ তারিখ নয়।',
'date_equals' => ':attribute একটি তারিখ হতে হবে যা :date এর সমান।',
'date_format' => ':attribute :format ফরম্যাটের সাথে মেলে না।',
'declined' => ':attribute প্রত্যাখ্যাত হতে হবে।',
'declined_if' => ':attribute প্রত্যাখ্যাত হতে হবে যখন :other হলো :value।',
'different' => ':attribute এবং :other আলাদা হতে হবে।',
'digits' => ':attribute :digits ডিজিট হতে হবে।',
'digits_between' => ':attribute :min এবং :max ডিজিটের মধ্যে হতে হবে।',
'dimensions' => ':attribute এর অকার্যকর চিত্র মাত্রা।',
'distinct' => ':attribute ক্ষেত্রটি একটি ডুপ্লিকেট মান ধারণ করে।',
'email' => ':attribute একটি বৈধ ইমেইল ঠিকানা হতে হবে।',
'ends_with' => ':attribute নিম্নলিখিতগুলির মধ্যে একটি দিয়ে শেষ হতে হবে: :values।',
'enum' => 'বেছে নেওয়া :attribute অবৈধ।',
'exists' => 'বেছে নেওয়া :attribute অবৈধ।',
'file' => ':attribute একটি ফাইল হতে হবে।',
'filled' => ':attribute ক্ষেত্রটি একটি মান থাকতে হবে।',
'gt' => [
    'array' => ':attribute এর মধ্যে :value এর বেশি আইটেম থাকতে হবে।',
    'file' => ':attribute এর আকার :value কিলোবাইটের বেশি হতে হবে।',
    'numeric' => ':attribute :value এর বেশি হতে হবে।',
    'string' => ':attribute :value অক্ষরের বেশি হতে হবে।',
],
'gte' => [
    'array' => ':attribute এর মধ্যে :value আইটেম বা তার বেশি থাকতে হবে।',
    'file' => ':attribute এর আকার :value কিলোবাইট বা তার বেশি হতে হবে।',
    'numeric' => ':attribute :value এর বেশি বা সমান হতে হবে।',
    'string' => ':attribute :value অক্ষরের বেশি বা সমান হতে হবে।',
],
'image' => ':attribute একটি চিত্র হতে হবে।',
'in' => 'বেছে নেওয়া :attribute অবৈধ।',
'in_array' => ':attribute ক্ষেত্রটি :other তে নেই।',
'integer' => ':attribute একটি পূর্ণসংখ্যা হতে হবে।',
'ip' => ':attribute একটি বৈধ IP ঠিকানা হতে হবে।',
'ipv4' => ':attribute একটি বৈধ IPv4 ঠিকানা হতে হবে।',
'ipv6' => ':attribute একটি বৈধ IPv6 ঠিকানা হতে হবে।',
'json' => ':attribute একটি বৈধ JSON স্ট্রিং হতে হবে।',
'lt' => [
    'array' => ':attribute এর মধ্যে :value এর কম আইটেম থাকতে হবে।',
    'file' => ':attribute এর আকার :value কিলোবাইটের কম হতে হবে।',
    'numeric' => ':attribute :value এর কম হতে হবে।',
    'string' => ':attribute :value অক্ষরের কম হতে হবে।',
],
'lte' => [
    'array' => ':attribute এর মধ্যে :value আইটেম বা তার কম থাকতে হবে।',
    'file' => ':attribute এর আকার :value কিলোবাইট বা তার কম হতে হবে।',
    'numeric' => ':attribute :value এর কম বা সমান হতে হবে।',
    'string' => ':attribute :value অক্ষরের কম বা সমান হতে হবে।',
],
'mac_address' => ':attribute একটি বৈধ MAC ঠিকানা হতে হবে।',
'max' => [
    'array' => ':attribute এর মধ্যে সর্বোচ্চ :max আইটেম থাকতে হবে।',
    'file' => ':attribute এর আকার সর্বোচ্চ :max কিলোবাইট হতে হবে।',
    'numeric' => ':attribute সর্বোচ্চ :max হতে হবে।',
    'string' => ':attribute সর্বোচ্চ :max অক্ষর হতে হবে।',
],
'mimes' => ':attribute একটি ফাইল হতে হবে যা এই ধরনের: :values।',
'mimetypes' => ':attribute একটি ফাইল হতে হবে যা এই ধরনের: :values।',
'min' => [
    'array' => ':attribute এর মধ্যে কমপক্ষে :min আইটেম থাকতে হবে।',
    'file' => ':attribute এর আকার কমপক্ষে :min কিলোবাইট হতে হবে।',
    'numeric' => ':attribute কমপক্ষে :min হতে হবে।',
    'string' => ':attribute কমপক্ষে :min অক্ষর হতে হবে।',
],
'multiple_of' => ':attribute :value এর গুণিতক হতে হবে।',
'not_in' => 'বেছে নেওয়া :attribute অবৈধ।',
'not_regex' => ':attribute ফরম্যাটটি অবৈধ।',
'numeric' => ':attribute একটি সংখ্যা হতে হবে।',
'present' => ':attribute ক্ষেত্রটি উপস্থিত থাকতে হবে।',
'prohibited' => ':attribute ক্ষেত্রটি নিষিদ্ধ।',
'prohibited_if' => ':attribute ক্ষেত্রটি নিষিদ্ধ যখন :other হলো :value।',
'prohibited_unless' => ':attribute ক্ষেত্রটি নিষিদ্ধ যদি না :other :values এর মধ্যে থাকে।',
'prohibits' => ':attribute ক্ষেত্রটি :other কে উপস্থিত হতে নিষিদ্ধ করে।',
'regex' => ':attribute ফরম্যাটটি অবৈধ।',
'required' => ':attribute ক্ষেত্রটি আবশ্যক।',
'required_array_keys' => ':attribute ক্ষেত্রটি এই এন্ট্রিগুলি থাকতে হবে: :values।',
'required_if' => ':attribute ক্ষেত্রটি আবশ্যক',
'required_unless' => ':attribute ক্ষেত্রটি আবশ্যক যদি না :other :values এর মধ্যে থাকে।',
'required_with' => ':attribute ক্ষেত্রটি আবশ্যক যখন :values উপস্থিত থাকে।',
'required_with_all' => ':attribute ক্ষেত্রটি আবশ্যক যখন :values উপস্থিত থাকে।',
'required_without' => ':attribute ক্ষেত্রটি আবশ্যক যখন :values উপস্থিত না থাকে।',
'required_without_all' => ':attribute ক্ষেত্রটি আবশ্যক যখন কোন :values উপস্থিত না থাকে।',
'same' => ':attribute এবং :other মেলাতে হবে।',
'size' => [
    'array' => ':attribute এর মধ্যে :size আইটেম থাকতে হবে।',
    'file' => ':attribute এর আকার হতে হবে :size কিলোবাইট।',
    'numeric' => ':attribute হতে হবে :size।',
    'string' => ':attribute হতে হবে :size অক্ষর।',
],
'starts_with' => ':attribute নিম্নলিখিতগুলির মধ্যে একটি দিয়ে শুরু হতে হবে: :values।',
'string' => ':attribute একটি স্ট্রিং হতে হবে।',
'timezone' => ':attribute একটি বৈধ টাইমজোন হতে হবে।',
'unique' => ':attribute ইতিমধ্যে নেওয়া হয়েছে।',
'uploaded' => ':attribute আপলোডে ব্যর্থ হয়েছে।',
'url' => ':attribute একটি বৈধ URL হতে হবে।',
'uuid' => ':attribute একটি বৈধ UUID হতে হবে।',

    /*
    |--------------------------------------------------------------------------
    | Custom Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | Here you may specify custom validation messages for attributes using the
    | convention "attribute.rule" to name the lines. This makes it quick to
    | specify a specific custom language line for a given attribute rule.
    |
    */

    'custom' => [
    'attribute-name' => [
        'rule-name' => 'কাস্টম-বার্তা',
    ],
],


    /*
    |--------------------------------------------------------------------------
    | Custom Validation Attributes
    |--------------------------------------------------------------------------
    |
    | The following language lines are used to swap our attribute placeholder
    | with something more reader friendly such as "E-Mail Address" instead
    | of "email". This simply helps us make our message more expressive.
    |
    */

    'attributes' => [],

];
