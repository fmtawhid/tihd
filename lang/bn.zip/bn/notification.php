<?php

return [
    'title' => 'বিজ্ঞপ্তি',
'lbl_text' => 'টেক্সট',
'lbl_module' => 'মডিউল',
'lbl_update' => 'সর্বশেষ আপডেট',
'title_template' => 'বিজ্ঞপ্তি টেমপ্লেট',
'lbl_id' => 'আইডি',
'lbl_label' => 'টেমপ্লেটের নাম',
'type' => 'প্রকার',
'lbl_type' => 'প্রকার',
'lbl_customer' => 'ব্যবহারকারী',
'lbl_status' => 'স্ট্যাটাস',
'lbl_action' => 'ক্রিয়া',
'lbl_to' => 'প্রাপক',
'lbl_bcc' => 'বিসি',
'lbl_cc' => 'সিসি',
'edit' => 'সম্পাদনা',
'parameters' => 'বিজ্ঞপ্তি পরামিতি',
'template' => 'টেমপ্লেট',
'notification_deleted' => 'বিজ্ঞপ্তি সফলভাবে মুছে ফেলা হয়েছে!'

];
