<?php

return [

    /*
     *
     * Shared translations.
     *
     */
    'title' => 'ল্যারাভেল ইনস্টলার',
'next' => 'পরবর্তী ধাপ',
'back' => 'পূর্ববর্তী',
'finish' => 'ইনস্টল',
'forms' => [
    'errorTitle' => 'নিম্নলিখিত ত্রুটিগুলি ঘটেছে:',
]

    ],

    /*
     *
     * Home page translations.
     *
     */
   'welcome' => [
    'templateTitle' => 'স্বাগতম',
    'title'   => 'ল্যারাভেল ইনস্টলার',
    'message' => 'সহজ ইনস্টলেশন এবং সেটআপ উইজার্ড।',
    'next'    => 'আবশ্যকতা পরীক্ষা করুন',
]
    ,

    /*
     *
     * Requirements page translations.
     *
     */
   'requirements' => [
    'templateTitle' => 'ধাপ ১ | সার্ভার প্রয়োজনীয়তা',
    'title' => 'সার্ভার প্রয়োজনীয়তা',
    'next'    => 'অনুমতি পরীক্ষা করুন',
],


    /*
     *
     * Permissions page translations.
     *
     */
   'permissions' => [
    'templateTitle' => 'ধাপ ২ | অনুমতিসমূহ',
    'title' => 'অনুমতিসমূহ',
    'next' => 'পরিবেশ কনফিগার করুন',
]

    ,

    /*
     *
     * Environment page translations.
     *
     */
   'environment' => [
    'menu' => [
        'templateTitle' => 'ধাপ ৩ | পরিবেশ সেটিংস',
        'title' => 'পরিবেশ সেটিংস',
        'desc' => 'অনুগ্রহ করে নির্বাচন করুন কিভাবে আপনি অ্যাপস এর <code>.env</code> ফাইল কনফিগার করতে চান।',
        'wizard-button' => 'ফর্ম উইজার্ড সেটআপ',
        'classic-button' => 'ক্লাসিক টেক্সট এডিটর',
    ],
]

 'environment' => [
    'menu' => [
        'templateTitle' => 'ধাপ ৩ | পরিবেশ সেটিংস',
        'title' => 'পরিবেশ সেটিংস',
        'desc' => 'অনুগ্রহ করে নির্বাচন করুন কিভাবে আপনি অ্যাপস এর <code>.env</code> ফাইল কনফিগার করতে চান।',
        'wizard-button' => 'ফর্ম উইজার্ড সেটআপ',
        'classic-button' => 'ক্লাসিক টেক্সট এডিটর',
    ],
    
    'wizard' => [
        'templateTitle' => 'ধাপ ৩ | পরিবেশ সেটিংস | গাইডেড উইজার্ড',
        'title' => 'গাইডেড <code>.env</code> উইজার্ড',
        'tabs' => [
            'environment' => 'পরিবেশ',
            'database' => 'ডাটাবেজ',
            'application' => 'অ্যাপ্লিকেশন',
        ],
        'form' => [
            'name_required' => 'একটি পরিবেশ নাম প্রয়োজন।',
            'app_name_label' => 'অ্যাপ নাম',
            'app_name_placeholder' => 'অ্যাপ নাম',
            'app_environment_label' => 'অ্যাপ পরিবেশ',
            'app_environment_label_local' => 'লোকাল',
            'app_environment_label_developement' => 'ডেভেলপমেন্ট',
            'app_environment_label_qa' => 'কিউএ',
            'app_environment_label_production' => 'প্রোডাকশন',
            'app_environment_label_other' => 'অন্যান্য',
            'app_environment_placeholder_other' => 'আপনার পরিবেশ লিখুন...',
            'app_debug_label' => 'অ্যাপ ডিবাগ',
            'app_debug_label_true' => 'সত্য',
            'app_debug_label_false' => 'মিথ্যা',
            'app_log_level_label' => 'অ্যাপ লগ লেভেল',
            'app_log_level_label_debug' => 'ডিবাগ',
            'app_log_level_label_info' => 'তথ্য',
            'app_log_level_label_notice' => 'বিজ্ঞপ্তি',
            'app_log_level_label_warning' => 'সতর্কতা',
            'app_log_level_label_error' => 'ত্রুটি',
            'app_log_level_label_critical' => 'গম্ভীর',
            'app_log_level_label_alert' => 'এলার্ট',
            'app_log_level_label_emergency' => 'জরুরি',
            'app_url_label' => 'অ্যাপ ইউআরএল',
            'app_url_placeholder' => 'অ্যাপ ইউআরএল',
            'db_connection_failed' => 'ডাটাবেজে সংযোগ স্থাপন সম্ভব হয়নি।',
            'db_connection_label' => 'ডাটাবেজ সংযোগ',
            'db_connection_label_mysql' => 'mysql',
            'db_connection_label_sqlite' => 'sqlite',
            'db_connection_label_pgsql' => 'pgsql',
            'db_connection_label_sqlsrv' => 'sqlsrv',
            'db_host_label' => 'ডাটাবেজ হোস্ট',
            'db_host_placeholder' => 'ডাটাবেজ হোস্ট',
            'db_port_label' => 'ডাটাবেজ পোর্ট',
            'db_port_placeholder' => 'ডাটাবেজ পোর্ট',
            'db_name_label' => 'ডাটাবেজ নাম',
            'db_name_placeholder' => 'ডাটাবেজ নাম',
            'db_username_label' => 'ডাটাবেজ ব্যবহারকারীর নাম',
            'db_username_placeholder' => 'ডাটাবেজ ব্যবহারকারীর নাম',
            'db_password_label' => 'ডাটাবেজ পাসওয়ার্ড',
            'db_password_placeholder' => 'ডাটাবেজ পাসওয়ার্ড',

            'app_tabs' => [
                'more_info' => 'আরো তথ্য',
                'broadcasting_title' => 'ব্রডকাস্টিং, ক্যাশিং, সেশন, এবং কিউ',
                'broadcasting_label' => 'ব্রডকাস্ট ড্রাইভার',
                'broadcasting_placeholder' => 'ব্রডকাস্ট ড্রাইভার',
                'cache_label' => 'ক্যাশ ড্রাইভার',
                'cache_placeholder' => 'ক্যাশ ড্রাইভার',
                'session_label' => 'সেশন ড্রাইভার',
                'session_placeholder' => 'সেশন ড্রাইভার',
                'queue_label' => 'কিউ ড্রাইভার',
                'queue_placeholder' => 'কিউ ড্রাইভার',
                'redis_label' => 'রেডিস ড্রাইভার',
                'redis_host' => 'রেডিস হোস্ট',
                'redis_password' => 'রেডিস পাসওয়ার্ড',
                'redis_port' => 'রেডিস পোর্ট',

                'mail_label' => 'মেইল',
                'mail_driver_label' => 'মেইল ড্রাইভার',
                'mail_driver_placeholder' => 'মেইল ড্রাইভার',
                'mail_host_label' => 'মেইল হোস্ট',
                'mail_host_placeholder' => 'মেইল হোস্ট',
                'mail_port_label' => 'মেইল পোর্ট',
                'mail_port_placeholder' => 'মেইল পোর্ট',
                'mail_username_label' => 'মেইল ব্যবহারকারীর নাম',
                'mail_username_placeholder' => 'মেইল ব্যবহারকারীর নাম',
                'mail_password_label' => 'মেইল পাসওয়ার্ড',
                'mail_password_placeholder' => 'মেইল পাসওয়ার্ড',
                'mail_encryption_label' => 'মেইল এনক্রিপশন',
                'mail_encryption_placeholder' => 'মেইল এনক্রিপশন',

                'pusher_label' => 'পুশার',
                'pusher_app_id_label' => 'পুশার অ্যাপ আইডি',
                'pusher_app_id_palceholder' => 'পুশার অ্যাপ আইডি',
                'pusher_app_key_label' => 'পুশার অ্যাপ কী',
                'pusher_app_key_palceholder' => 'পুশার অ্যাপ কী',
                'pusher_app_secret_label' => 'পুশার অ্যাপ সিক্রেট',
                'pusher_app_secret_palceholder' => 'পুশার অ্যাপ সিক্রেট',
            ],
            'buttons' => [
                'setup_database' => 'ডাটাবেজ সেটআপ',
                'setup_application' => 'অ্যাপ্লিকেশন সেটআপ',
                'install' => 'ইনস্টল',
            ],
        ],
    ],
    'classic' => [
        'templateTitle' => 'ধাপ ৩ | পরিবেশ সেটিংস | ক্লাসিক এডিটর',
        'title' => 'ক্লাসিক পরিবেশ এডিটর',
        'save' => '.env সংরক্ষণ করুন',
        'back' => 'ফর্ম উইজার্ড ব্যবহার করুন',
        'install' => 'সংরক্ষণ করুন এবং ইনস্টল করুন',
    ],
    'success' => 'আপনার .env ফাইল সেটিংস সংরক্ষিত হয়েছে।',
    'errors' => '.env ফাইল সংরক্ষণ করা সম্ভব হয়নি, অনুগ্রহ করে এটি ম্যানুয়ালি তৈরি করুন।',
],

'install' => 'ইনস্টল',


    /*
     *
     * Installed Log translations.
     *
     */
    'installed' => [
      'success_log_message' => 'Laravel Installer সফলভাবে ইনস্টল করা হয়েছে ',

    ],

    /*
     *
     * Final page translations.
     *
     */
'final' => [
    'title' => 'ইনস্টলেশন শেষ',
    'templateTitle' => 'ইনস্টলেশন শেষ',
    'finished' => 'অ্যাপ্লিকেশন সফলভাবে ইনস্টল করা হয়েছে।',
    'migration' => 'মাইগ্রেশন এবং বীজ কনসোল আউটপুট:',
    'console' => 'অ্যাপ্লিকেশন কনসোল আউটপুট:',
    'log' => 'ইনস্টলেশন লগ এন্ট্রি:',
    'env' => 'ফাইনাল .env ফাইল:',
    'exit' => 'বের হতে এখানে ক্লিক করুন',
    'user_website' => 'ব্যবহারকারীর ওয়েবসাইট',
    'admin_panel' => 'এডমিন প্যানেল'
],


    /*
     *
     * Update specific translations
     *
     */
    'updater' => [
        /*
         *
         * Shared translations.
         *
         */
        'title' => 'লারাভেল আপডেটার',

        /*
         *
         * Welcome page translations for update feature.
         *
         */
       'welcome' => [
    'title'   => 'আপডেটারে স্বাগতম',
    'message' => 'আপডেট উইজার্ডে স্বাগতম।',
],
 

        /*
         *
         * Welcome page translations for update feature.
         *
         */
       'overview' => [
    'title'   => 'পর্যালোচনা',
    'message' => 'একটি আপডেট রয়েছে।| :number টি আপডেট রয়েছে।',
    'install_updates' => 'আপডেট ইনস্টল করুন',
],


        /*
         *
         * Final page translations.
         *
         */
       'final' => [
            'title' => 'সম্পন্ন',
            'finished' => 'অ্যাপ্লিকেশনের ডাটাবেস সফলভাবে আপডেট করা হয়েছে।',
            'exit' => 'বের হতে এখানে ক্লিক করুন',
        ],

        'log' => [
            'success_message' => 'ল্যারাভেল ইনস্টলার সফলভাবে আপডেট হয়েছে ',
        ],
    ],
];
