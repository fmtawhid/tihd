<?php

return [
    'title' => 'ভিডিও',
'add_title' => 'নতুন ভিডিও',
'edit_title' => 'ভিডিও সম্পাদনা',
'singular_title' => 'ভিডিও',
'lbl_logo' => 'লোগো',
'lbl_title' => 'শিরোনাম',
'video_list' => 'ভিডিও তালিকা',
'video_details' => 'ভিডিও বিবরণ',
'lbl_download_status' => 'ডাউনলোড অবস্থান',
'lbl_video_download_type' => 'ভিডিও ডাউনলোড ধরণ',
'download_url' => 'ডাউনলোড ইউআরএল',
'lbl_download_quality_info' => 'ডাউনলোড গুণমান তথ্য',
'lbl_quality_info_message' => 'গুণমান তথ্য বার্তা',
'lbl_quality_video_download_type' => 'গুণমান ভিডিও ডাউনলোড ধরণ',
'lbl_download_info' => 'ডাউনলোড তথ্য',
'download_quality_video_url' => 'ডাউনলোড গুণমান ভিডিও ইউআরএল',
'lbl_video_download_quality' => 'ভিডিও ডাউনলোড গুণমান'




 ];
