<?php

return [
   'title' => 'প্ল্যান সীমা',
'lbl_title' => 'শিরোনাম',
'lbl_status' => 'অবস্থা',
'lbl_description' => 'বর্ণনা',
'add_planlimit_title' => 'নতুন প্ল্যান সীমা যোগ করুন',
'edit_planlimit_title' => 'প্ল্যান সীমা সম্পাদনা করুন'

];
