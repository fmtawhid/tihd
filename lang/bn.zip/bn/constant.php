<?php

return [
   'title' => 'স্থিরতা',
'lbl_type' => 'ধরন',
'lbl_name' => 'নাম',
'lbl_value' => 'মূল্য',
'lbl_sub_type' => 'উপধরন',
'lbl_sequence' => 'সিকোয়েন্স',
'lbl_status' => 'অবস্থা',
'video_quality' => 'ভিডিও মান',
'movie_language' => 'চলচ্চিত্র ভাষা',
'UPLOAD_URL_TYPE' => 'ইউআরএল ধরন',
'constant_title' => 'নতুন স্থিরতা',
'select_type' => 'ধরন নির্বাচন করুন',
'constant_edit' => 'স্থিরতা সম্পাদনা করুন'

];
