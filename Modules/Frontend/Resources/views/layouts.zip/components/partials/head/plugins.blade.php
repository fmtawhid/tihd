<link rel="stylesheet" href="{{ asset('vendor/swiperSlider/swiper.min.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/slick/slick.css') }}">
<link rel="stylesheet" href="{{ asset('vendor/slick/slick-theme.css') }}">
