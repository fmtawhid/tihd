<div class="logo-default">
    <a class="navbar-brand text-primary atb" href="{{route('user.login')}}">

        @php

            $logo=GetSettingValue('dark_logo') ??  asset(setting('dark_logo'));
        @endphp


        <img class="img-fluid logo atb" src="{{ $logo }}" alt="streamit">
    </a>
</div>
