<div class="iq-top-ten-block">
    <div class="block-image position-relative">
        <div class="img-box">
            <a class="overly-images" href="/movie-details">
                <img src="../img/web-img/movie.webp" alt="movie-card" class="img-fluid object-cover top-ten-img">
            </a>
            <span class="top-ten-numbers texture-text">1</span>
        </div>
    </div>
</div>