<?php

return [
    'name' => 'Frontend',
];
