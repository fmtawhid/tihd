<?php

return [
    'name' => 'Entertainment',
];
